# Vitalora cinematic anatomy upgrade

## What will change

Upgrade the existing project without replacing its pages or navigation. Keep the login screen first, and build a complete five-section Home experience inspired by the uploaded anatomical reference. The watermarked image will remain a reference only.

### 1. Cinematic login
- Replace the still skeleton with a large, lazily loaded 3D anatomical scene when a suitable licensed model is available.
- Preserve Log in / Sign up, password visibility, validation, and preview access; keep the form clear of the body.
- Do not pretend authentication works. The current project has no connected account service; real login requires enabling Lovable Cloud and is a separate dependency, not a simulated success.

### 2. Five substantial Home sections
1. **DNA:** central animated golden DNA, “Explore the Science of You,” healthcare search, anatomy and assistant actions, service shortcuts, and a scroll cue.
2. **Exploded anatomy:** a prominent front-facing model with supported parts arranged scientifically, progressive labels, assembled/exploded states, rotation, zoom, camera reset, front/back views, supported layer toggles, and anatomy search.
3. **Explore and learn:** selectable anatomy with distinct educational records, location, function, body system, common conditions, and safety information; include a keyboard-accessible searchable list.
4. **Healthcare universe:** filtered feature groups that link to existing Search, Healthcare, Pharmacy, and Finance pages. Mark unavailable integrations honestly.
5. **About and trust:** mission, AI and Blood Band context, medical safety, privacy principles, education and feedback/support destinations where available, and final anatomy/assistant actions. Do not invent reviews, contact details, or legal promises.

### 3. Navigation and accessibility
- Preserve Home | Search | Finance | Pharmacy | Healthcare | About.
- Add sticky navigation, Home section navigation with active state, and accessible mobile controls.
- Keep normal scrolling; no indefinite animation pinning.
- Provide reduced-motion behavior, model loading/error states, and a non-WebGL text-based anatomy experience.

## Asset gate and honest scope

The existing anatomy asset is a JPG, not a selectable 3D model. First verify a downloadable CC0/public-domain anatomy model and inspect its mesh names and structure. Only expose structures genuinely present in the asset. Record source, license, size, and loading requirements.

If no suitable licensed multi-part model can be obtained, report that dependency and request an appropriately licensed GLB/GLTF rather than substitute a flat image, fake organs, or primitive bones. Complete the five-section layout and supported interactions, but do not call the realistic exploded-anatomy requirement complete without the asset.

Existing medicine checkout, patient/admin portals, and live healthcare integrations will be preserved if present; this visual upgrade does not create or claim missing services.

## Technical approach

- Retain TanStack Start, React, TypeScript, existing design tokens, and React Three Fiber.
- Use one shared Home canvas where practical, with scroll-driven camera and assembly targets; lazy-load model assets and cap rendering complexity on small screens.
- Use GSAP ScrollTrigger for coordinated transitions if the existing animation stack does not already cover them; clean up all listeners and animation instances.
- Separate anatomy records, model adapters, controls, and Home section content into focused modules.
- Keep unique page metadata and document structural decisions and asset provenance.

## Verification

- Test login validation and preview entry without claiming real authentication.
- Verify all five Home sections and the original navigation routes.
- Exercise actual supported anatomy selection, search, layers, assembly controls, and camera controls in the browser.
- Check desktop, tablet, and mobile layouts, reduced-motion behavior, model load failures, and non-WebGL fallback.
- Run relevant existing tests and inspect preview errors before completion.