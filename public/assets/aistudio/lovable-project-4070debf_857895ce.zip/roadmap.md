# Vitalora upgrade

- [ ] Build five-section scrolling Home and shared animated DNA canvas.
- [ ] Verify licensed anatomy assets; implement only genuinely supported 3D structures, otherwise provide honest educational fallback.
- [ ] Add searchable anatomy learning records and contextual details.
- [ ] Connect ecosystem cards and improve sticky/mobile navigation without replacing existing pages.
- [ ] Preserve login-first flow and make unavailable account/assistant actions explicit.
- [ ] Verify routes, interactions, responsive layouts, reduced motion, WebGL fallback, and tests.