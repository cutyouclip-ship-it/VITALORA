import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Bell, Menu, Search, Sparkles, X } from "lucide-react";

const links = [
  { to: "/home", label: "Home" },
  { to: "/search", label: "Search" },
  { to: "/finance", label: "Finance" },
  { to: "/pharmacy", label: "Pharmacy" },
  { to: "/healthcare", label: "Healthcare" },
  { to: "/about", label: "About" },
] as const;

export function Logo() {
  return (
    <Link to="/home" className="flex items-center gap-2.5 shrink-0">
      <span className="grid h-9 w-9 place-items-center rounded-full bg-gold shadow-gold">
        <span className="h-3.5 w-3.5 rounded-full bg-background" />
      </span>
      <span className="text-lg font-semibold tracking-tight">vitalora</span>
    </Link>
  );
}

export function SiteNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 px-4 pt-4">
      <nav className="glass mx-auto flex max-w-7xl items-center justify-between gap-4 rounded-2xl px-4 py-2.5">
        <Logo />
        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <li key={l.to}>
              <Link
                to={l.to}
                className="relative rounded-full px-4 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground data-[status=active]:bg-muted data-[status=active]:text-foreground"
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-1.5">
          <Link to="/search" aria-label="Search" className="grid h-10 w-10 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground">
            <Search className="h-4 w-4" />
          </Link>
          <button aria-label="AI assistant" className="hidden h-10 items-center gap-2 rounded-full bg-gold px-4 text-sm font-medium text-primary-foreground shadow-gold sm:flex">
            <Sparkles className="h-4 w-4" /> Ask AI
          </button>
          <button aria-label="Notifications" className="grid h-10 w-10 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground">
            <Bell className="h-4 w-4" />
          </button>
          <button aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)} className="grid h-10 w-10 place-items-center rounded-full hover:bg-muted lg:hidden">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>
      {open && (
        <ul className="glass mx-auto mt-2 grid max-w-7xl gap-1 rounded-2xl p-2 lg:hidden">
          {links.map((l) => (
            <li key={l.to}>
              <Link to={l.to} onClick={() => setOpen(false)} className="block rounded-xl px-4 py-3 text-sm data-[status=active]:bg-muted">
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </header>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh bg-background bg-ambient">
      <SiteNav />
      <main>{children}</main>
    </div>
  );
}
