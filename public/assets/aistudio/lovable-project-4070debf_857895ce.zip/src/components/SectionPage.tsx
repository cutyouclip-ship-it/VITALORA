import type { LucideIcon } from "lucide-react";
import { AppShell } from "./SiteNav";

export type Feature = { title: string; desc: string; icon: LucideIcon; status?: string };

export function SectionPage({ eyebrow, title, intro, features }: { eyebrow: string; title: string; intro: string; features: Feature[] }) {
  return (
    <AppShell>
      <section className="mx-auto max-w-7xl px-6 pb-24 pt-16">
        <p className="animate-rise text-xs font-semibold uppercase tracking-[0.25em] text-primary">{eyebrow}</p>
        <h1 className="animate-rise mt-3 max-w-2xl text-4xl font-semibold tracking-tight md:text-5xl">{title}</h1>
        <p className="animate-rise mt-4 max-w-xl text-muted-foreground">{intro}</p>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <article key={f.title} style={{ animationDelay: `${i * 60}ms` }} className="glass animate-rise group rounded-2xl p-6 transition-transform hover:-translate-y-1">
              <div className="flex items-start justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-muted text-primary transition-colors group-hover:bg-gold group-hover:text-primary-foreground">
                  <f.icon className="h-5 w-5" />
                </span>
                <span className="rounded-full border border-border px-2.5 py-1 text-[11px] text-muted-foreground">{f.status ?? "Coming soon"}</span>
              </div>
              <h2 className="mt-5 font-semibold">{f.title}</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
            </article>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
