import { Canvas, useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";

const TURNS = 3.2;
const HEIGHT = 14;
const RADIUS = 1.6;
const PER_STRAND = 1400;

function Helix() {
  const group = useRef<THREE.Group>(null);
  const { strand, rungs, dust } = useMemo(() => {
    const s: number[] = [];
    for (let k = 0; k < 2; k++) {
      for (let i = 0; i < PER_STRAND; i++) {
        const t = i / PER_STRAND;
        const a = t * Math.PI * 2 * TURNS + k * Math.PI;
        const j = 0.18;
        s.push(
          Math.cos(a) * RADIUS + (Math.random() - 0.5) * j,
          (t - 0.5) * HEIGHT + (Math.random() - 0.5) * j,
          Math.sin(a) * RADIUS + (Math.random() - 0.5) * j,
        );
      }
    }
    const r: number[] = [];
    const count = 46;
    for (let i = 0; i < count; i++) {
      const t = i / count;
      const a = t * Math.PI * 2 * TURNS;
      for (let p = 0; p < 26; p++) {
        const u = p / 25;
        const x = THREE.MathUtils.lerp(Math.cos(a), Math.cos(a + Math.PI), u) * RADIUS;
        const z = THREE.MathUtils.lerp(Math.sin(a), Math.sin(a + Math.PI), u) * RADIUS;
        r.push(x, (t - 0.5) * HEIGHT, z);
      }
    }
    const d: number[] = [];
    for (let i = 0; i < 600; i++) d.push((Math.random() - 0.5) * 22, (Math.random() - 0.5) * 16, (Math.random() - 0.5) * 10 - 3);
    return { strand: new Float32Array(s), rungs: new Float32Array(r), dust: new Float32Array(d) };
  }, []);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += Math.min(delta, 0.05) * 0.25;
  });

  return (
    <>
      <group ref={group} rotation={[0, 0, -0.55]}>
        <points>
          <bufferGeometry>
            <bufferAttribute attach="attributes-position" args={[strand, 3]} />
          </bufferGeometry>
          <pointsMaterial size={0.07} color="#ffb547" transparent opacity={0.95} blending={THREE.AdditiveBlending} depthWrite={false} />
        </points>
        <points>
          <bufferGeometry>
            <bufferAttribute attach="attributes-position" args={[rungs, 3]} />
          </bufferGeometry>
          <pointsMaterial size={0.045} color="#ff8a2a" transparent opacity={0.7} blending={THREE.AdditiveBlending} depthWrite={false} />
        </points>
      </group>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[dust, 3]} />
        </bufferGeometry>
        <pointsMaterial size={0.04} color="#ffd9a0" transparent opacity={0.45} depthWrite={false} />
      </points>
    </>
  );
}

export default function DnaHelix() {
  return (
    <Canvas camera={{ position: [0, 0, 11], fov: 50 }} dpr={[1, 2]} gl={{ alpha: true, antialias: true }}>
      <Helix />
    </Canvas>
  );
}
