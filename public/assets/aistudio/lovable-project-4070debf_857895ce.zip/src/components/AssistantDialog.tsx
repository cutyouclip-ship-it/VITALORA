import { useState } from "react";
import { Sparkles, ArrowUpRight, X } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";

export function AssistantDialog({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  return <Dialog open={open} onOpenChange={setOpen}>
    <DialogTrigger asChild><Button aria-label="AI assistant" className="bg-gold shadow-gold" size={compact ? "sm" : "lg"}><Sparkles /> <span>Ask AI</span></Button></DialogTrigger>
    <DialogContent className="border-border bg-popover">
      <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-muted text-primary"><Sparkles /></div>
      <DialogTitle>Vitalora AI</DialogTitle>
      <DialogDescription>The medical assistant is not connected yet. You can explore the anatomy library and healthcare service previews now.</DialogDescription>
      <p className="text-sm text-muted-foreground">Educational information is not a diagnosis. For urgent symptoms, seek emergency medical care.</p>
      <div className="flex flex-wrap gap-3"><Button asChild><Link to="/search" onClick={() => setOpen(false)}>Healthcare search <ArrowUpRight /></Link></Button><Button variant="outline" onClick={() => setOpen(false)}><X /> Close</Button></div>
    </DialogContent>
  </Dialog>;
}