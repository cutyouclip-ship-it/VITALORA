import { describe, expect, it } from "vitest";
import { findAnatomy, searchAnatomy } from "@/lib/anatomy";

describe("Anatomy selection", () => {
  it("maps the heart and lungs to their own distinct systems and functions", () => {
    expect(findAnatomy("heart")?.system).toBe("Cardiovascular");
    expect(findAnatomy("lungs")?.system).toBe("Respiratory");
    expect(findAnatomy("heart")?.function).not.toBe(findAnatomy("lungs")?.function);
  });
  it("filters the accessible list by search and system", () => {
    expect(searchAnatomy("kidney").map(r => r.id)).toEqual(["kidneys"]);
    expect(searchAnatomy("", "Digestive").map(r => r.id)).toEqual(["liver", "stomach", "intestines"]);
    expect(searchAnatomy("heart", "Skeletal")).toEqual([]);
  });
});