import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck, Calculator, FileCheck, Building2, Receipt, BookOpen } from "lucide-react";
import { SectionPage } from "@/components/SectionPage";

export const Route = createFileRoute("/finance")({
  head: () => ({
    meta: [
      { title: "Finance — Vitalora" },
      { name: "description", content: "Compare insurance policies, estimate premiums, track claims and medical expenses." },
      { property: "og:title", content: "Finance — Vitalora" },
      { property: "og:description", content: "Compare insurance policies, estimate premiums, track claims and medical expenses." },
    ],
  }),
  component: () => <SectionPage eyebrow="Finance" title="Insurance without the fine print." intro="Compare insurance policies, estimate premiums, track claims and medical expenses." features={[{title:"Policy comparison",desc:"Side-by-side coverage.",icon:ShieldCheck},{title:"Premium estimator",desc:"With clearly stated assumptions.",icon:Calculator},{title:"Claims",desc:"Submit and track claims.",icon:FileCheck},{title:"Cashless hospitals",desc:"Find network hospitals.",icon:Building2},{title:"Expense tracking",desc:"Bills and invoices.",icon:Receipt},{title:"Learn & FAQs",desc:"Insurance explained simply.",icon:BookOpen}]} />,
});
