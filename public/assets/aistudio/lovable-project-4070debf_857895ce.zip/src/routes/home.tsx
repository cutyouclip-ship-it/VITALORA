import { createFileRoute, Link } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState } from "react";
import { ArrowUpRight, Droplets, Siren, Pill, Stethoscope, Building2, FileText, Search } from "lucide-react";
import { AppShell } from "@/components/SiteNav";

const DnaHelix = lazy(() => import("@/components/DnaHelix"));

export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Home — Vitalora" },
      { name: "description", content: "Your Vitalora health universe: blood, pharmacy, doctors, hospitals and records." },
      { property: "og:title", content: "Home — Vitalora" },
      { property: "og:description", content: "Your Vitalora health universe in one place." },
    ],
  }),
  component: Home,
});

const quick = [
  { to: "/healthcare", title: "Blood availability", meta: "Bihar network", icon: Droplets },
  { to: "/healthcare", title: "Emergency", meta: "Ambulance & contacts", icon: Siren },
  { to: "/pharmacy", title: "Pharmacy", meta: "Medicine catalogue", icon: Pill },
  { to: "/healthcare", title: "Doctors", meta: "Appointments", icon: Stethoscope },
  { to: "/healthcare", title: "Hospitals", meta: "Beds & facilities", icon: Building2 },
  { to: "/healthcare", title: "Medical records", meta: "Reports & history", icon: FileText },
] as const;

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  return (
    <AppShell>
      <section className="relative mx-auto -mt-20 grid min-h-[92dvh] max-w-7xl items-center px-6 pt-20 lg:grid-cols-2">
        <div className="pointer-events-none absolute inset-0 lg:left-1/3">
          {ready && <Suspense fallback={null}><DnaHelix /></Suspense>}
        </div>
        <div className="relative z-10 max-w-xl">
          <p className="animate-rise text-xs font-semibold uppercase tracking-[0.25em] text-primary">AI healthcare universe</p>
          <h1 className="animate-rise mt-4 text-4xl font-semibold leading-[1.1] tracking-tight md:text-6xl">
            Care, decoded <span className="text-gold">down to the gene.</span>
          </h1>
          <p className="animate-rise mt-5 text-muted-foreground">Find blood, medicines, doctors and hospitals — and understand your body — from one calm place.</p>
          <Link to="/search" className="glass animate-rise mt-8 flex h-14 items-center gap-3 rounded-2xl px-5 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <Search className="h-4 w-4 text-primary" /> Try “O+ blood near Patna” or “bukhar ki dawa”
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-semibold tracking-tight">Quick access</h2>
          <span className="text-xs text-muted-foreground">Live data not yet connected</span>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {quick.map((q, i) => (
            <Link key={q.title} to={q.to} style={{ animationDelay: `${i * 70}ms` }} className="glass animate-rise group flex items-center justify-between rounded-2xl p-6 transition-transform hover:-translate-y-1">
              <div className="flex items-center gap-4">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-muted text-primary"><q.icon className="h-5 w-5" /></span>
                <div>
                  <p className="font-semibold">{q.title}</p>
                  <p className="text-sm text-muted-foreground">{q.meta}</p>
                </div>
              </div>
              <span className="grid h-9 w-9 place-items-center rounded-full border border-border transition-colors group-hover:bg-gold group-hover:text-primary-foreground"><ArrowUpRight className="h-4 w-4" /></span>
            </Link>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
