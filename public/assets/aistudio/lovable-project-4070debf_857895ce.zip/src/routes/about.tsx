import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, ShieldCheck, Languages } from "lucide-react";
import { SectionPage } from "@/components/SectionPage";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Vitalora" },
      { name: "description", content: "Vitalora is a premium AI healthcare platform built to make care honest, clear and accessible." },
      { property: "og:title", content: "About — Vitalora" },
      { property: "og:description", content: "Vitalora is a premium AI healthcare platform built to make care honest, clear and accessible." },
    ],
  }),
  component: () => <SectionPage eyebrow="About" title="Healthcare that tells the truth." intro="Vitalora is a premium AI healthcare platform built to make care honest, clear and accessible." features={[{title:"Honest data",desc:"Every figure shows its source and freshness.",icon:ShieldCheck,status:"Principle"},{title:"AI that explains",desc:"Plain language, never a diagnosis.",icon:Sparkles,status:"Principle"},{title:"Built for India",desc:"Hindi, English and Hinglish.",icon:Languages,status:"Principle"}]} />,
});
