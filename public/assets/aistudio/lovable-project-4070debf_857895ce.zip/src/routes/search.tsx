import { createFileRoute } from "@tanstack/react-router";
import { Search, Stethoscope, Droplets, Pill, BookOpen, Languages } from "lucide-react";
import { SectionPage } from "@/components/SectionPage";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Search — Vitalora" },
      { name: "description", content: "One search across doctors, hospitals, blood banks, medicines, articles and anatomy." },
      { property: "og:title", content: "Search — Vitalora" },
      { property: "og:description", content: "One search across doctors, hospitals, blood banks, medicines, articles and anatomy." },
    ],
  }),
  component: () => <SectionPage eyebrow="Search" title="Ask anything, in any language." intro="One search across doctors, hospitals, blood banks, medicines, articles and anatomy." features={[{title:"Universal search",desc:"Doctors, hospitals, medicines and more.",icon:Search},{title:"Doctors",desc:"Filter by specialty and location.",icon:Stethoscope},{title:"Blood banks",desc:"By district and blood group.",icon:Droplets},{title:"Medicines",desc:"By generic or brand name.",icon:Pill},{title:"Articles",desc:"Verified health reading.",icon:BookOpen},{title:"Hindi, English, Hinglish",desc:"Type the way you talk.",icon:Languages}]} />,
});
