import { createFileRoute } from "@tanstack/react-router";
import { Pill, FileUp, ShoppingCart, Truck, Receipt, Boxes } from "lucide-react";
import { SectionPage } from "@/components/SectionPage";

export const Route = createFileRoute("/pharmacy")({
  head: () => ({
    meta: [
      { title: "Pharmacy — Vitalora" },
      { name: "description", content: "A searchable medicine catalogue with prescriptions, cart, checkout and order tracking." },
      { property: "og:title", content: "Pharmacy — Vitalora" },
      { property: "og:description", content: "A searchable medicine catalogue with prescriptions, cart, checkout and order tracking." },
    ],
  }),
  component: () => <SectionPage eyebrow="Pharmacy" title="Medicines, verified and delivered." intro="A searchable medicine catalogue with prescriptions, cart, checkout and order tracking." features={[{title:"Medicine catalogue",desc:"100+ reference records.",icon:Pill},{title:"Prescription upload",desc:"Pharmacist verification.",icon:FileUp},{title:"Cart & checkout",desc:"Address book and delivery.",icon:ShoppingCart},{title:"Order tracking",desc:"History and status.",icon:Truck},{title:"Invoices",desc:"Itemized with tax.",icon:Receipt},{title:"Inventory",desc:"For pharmacy staff.",icon:Boxes}]} />,
});
