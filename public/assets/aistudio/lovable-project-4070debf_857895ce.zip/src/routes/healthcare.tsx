import { createFileRoute } from "@tanstack/react-router";
import { Siren, Droplets, Building2, Stethoscope, Video, FlaskConical, FileText, Scissors, HeartPulse, Activity } from "lucide-react";
import { SectionPage } from "@/components/SectionPage";

export const Route = createFileRoute("/healthcare")({
  head: () => ({
    meta: [
      { title: "Healthcare — Vitalora" },
      { name: "description", content: "Emergency, blood, hospitals, doctors, consultations, labs, records, surgery, wellness and recovery." },
      { property: "og:title", content: "Healthcare — Vitalora" },
      { property: "og:description", content: "Emergency, blood, hospitals, doctors, consultations, labs, records, surgery, wellness and recovery." },
    ],
  }),
  component: () => <SectionPage eyebrow="Healthcare" title="Fifty ways to care, organized in ten." intro="Emergency, blood, hospitals, doctors, consultations, labs, records, surgery, wellness and recovery." features={[{title:"Emergency & ambulance",desc:"Contacts and dispatch.",icon:Siren},{title:"Blood network",desc:"Bihar blood availability.",icon:Droplets},{title:"Hospitals & beds",desc:"Facilities directory.",icon:Building2},{title:"Doctors & appointments",desc:"Book a visit.",icon:Stethoscope},{title:"Online consultations",desc:"See a doctor by video.",icon:Video},{title:"Lab tests & reports",desc:"Book, upload, download.",icon:FlaskConical},{title:"Medical records",desc:"Your history, organized.",icon:FileText},{title:"Surgery & procedures",desc:"Plan with confidence.",icon:Scissors},{title:"Preventive wellness",desc:"BMI, reminders, education.",icon:HeartPulse},{title:"Recovery & care",desc:"Smart hospital follow-up.",icon:Activity}]} />,
});
