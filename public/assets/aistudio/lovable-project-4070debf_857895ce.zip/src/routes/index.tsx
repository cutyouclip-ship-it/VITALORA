import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff, ShieldCheck, Info } from "lucide-react";
import anatomy from "@/assets/anatomy.jpg";
import { Logo } from "@/components/SiteNav";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sign in — Vitalora" },
      { name: "description", content: "Sign in to Vitalora, the AI healthcare universe." },
      { property: "og:title", content: "Sign in — Vitalora" },
      { property: "og:description", content: "Sign in to Vitalora, the AI healthcare universe." },
    ],
  }),
  component: Auth,
});

const labels = [
  { name: "Cranium", top: "6%", left: "56%", side: "r" },
  { name: "Clavicle", top: "17%", left: "64%", side: "r" },
  { name: "Rib cage", top: "26%", left: "30%", side: "l" },
  { name: "Lumbar spine", top: "36%", left: "54%", side: "r" },
  { name: "Pelvis", top: "42%", left: "30%", side: "l" },
  { name: "Femur", top: "57%", left: "58%", side: "r" },
  { name: "Patella", top: "68%", left: "32%", side: "l" },
  { name: "Tibia", top: "80%", left: "58%", side: "r" },
];

function Auth() {
  const [tab, setTab] = useState<"login" | "signup">("login");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const id = String(f.get("id") ?? "").trim();
    const pw = String(f.get("password") ?? "");
    setNotice("");
    if (!/^\S+@\S+\.\S+$/.test(id) && !/^\+?\d{10,13}$/.test(id)) return setError("Enter a valid email or phone number.");
    if (pw.length < 8) return setError("Password must be at least 8 characters.");
    if (tab === "signup" && !f.get("consent")) return setError("Please accept the privacy terms to continue.");
    setError("");
    setNotice("Accounts aren't connected yet, so you can't sign in for real. Use the preview link below to explore.");
  }

  return (
    <main className="relative grid min-h-dvh overflow-hidden bg-background lg:grid-cols-[1.1fr_1fr]">
      <div className="absolute inset-0 bg-ambient" />
      <section className="relative hidden items-center justify-center lg:flex">
        <div className="relative h-[88dvh] aspect-[896/1408]">
          <img src={anatomy} alt="Anatomical human skeleton" width={896} height={1408} className="h-full w-full object-contain mix-blend-lighten" />
          {labels.map((l, i) => (
            <div key={l.name} className="animate-rise absolute flex items-center gap-2" style={{ top: l.top, left: l.left, animationDelay: `${300 + i * 90}ms`, flexDirection: l.side === "l" ? "row-reverse" : "row" }}>
              <span className="h-2 w-2 rounded-full bg-primary shadow-gold" />
              <span className="h-px w-12 bg-primary/60" />
              <span className="glass whitespace-nowrap rounded-full px-3 py-1 text-xs">{l.name}</span>
            </div>
          ))}
        </div>
        <div className="absolute left-10 top-8"><Logo /></div>
      </section>

      <section className="relative flex items-center justify-center px-6 py-12">
        <div className="glass animate-rise w-full max-w-md rounded-3xl p-8">
          <div className="lg:hidden mb-6"><Logo /></div>
          <h1 className="text-3xl font-semibold tracking-tight">{tab === "login" ? "Welcome back" : "Create your account"}</h1>
          <p className="mt-2 text-sm text-muted-foreground">Your health universe, understood.</p>

          <div role="tablist" className="mt-6 grid grid-cols-2 rounded-full bg-muted p-1 text-sm">
            {(["login", "signup"] as const).map((t) => (
              <button key={t} role="tab" aria-selected={tab === t} onClick={() => { setTab(t); setError(""); setNotice(""); }} className={`rounded-full py-2 transition-colors ${tab === t ? "bg-gold text-primary-foreground font-medium" : "text-muted-foreground"}`}>
                {t === "login" ? "Log in" : "Sign up"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} noValidate className="mt-6 space-y-4">
            {tab === "signup" && (
              <Field label="Full name" name="name" placeholder="Aarav Sharma" />
            )}
            <Field label="Email or phone" name="id" placeholder="you@example.com" />
            <div>
              <label htmlFor="password" className="text-xs text-muted-foreground">Password</label>
              <div className="relative mt-1.5">
                <input id="password" name="password" type={show ? "text" : "password"} maxLength={128} className="h-12 w-full rounded-xl border border-input bg-background/40 px-4 pr-12 text-sm outline-none placeholder:text-muted-foreground focus:border-primary" placeholder="••••••••" />
                <button type="button" aria-label={show ? "Hide password" : "Show password"} onClick={() => setShow(!show)} className="absolute right-2 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-lg text-muted-foreground hover:text-foreground">
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            {tab === "login" ? (
              <div className="text-right"><button type="button" className="text-xs text-primary hover:underline">Forgot password?</button></div>
            ) : (
              <label className="flex items-start gap-2 text-xs text-muted-foreground">
                <input type="checkbox" name="consent" className="mt-0.5 accent-[var(--primary)]" />
                I agree to the privacy policy and consent to processing of my health data.
              </label>
            )}
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
            {notice && <p role="status" className="flex gap-2 rounded-xl border border-border bg-muted/60 p-3 text-xs text-muted-foreground"><Info className="h-4 w-4 shrink-0 text-accent" />{notice}</p>}
            <button className="h-12 w-full rounded-xl bg-gold font-medium text-primary-foreground shadow-gold transition-transform active:scale-[0.98]">
              {tab === "login" ? "Log in" : "Create account"}
            </button>
          </form>

          <Link to="/home" className="mt-4 block text-center text-sm text-muted-foreground hover:text-foreground">Explore preview →</Link>
          <p className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground"><ShieldCheck className="h-3.5 w-3.5" /> Encrypted. Your data stays yours.</p>
        </div>
      </section>
    </main>
  );
}

function Field({ label, name, placeholder }: { label: string; name: string; placeholder: string }) {
  return (
    <div>
      <label htmlFor={name} className="text-xs text-muted-foreground">{label}</label>
      <input id={name} name={name} maxLength={255} placeholder={placeholder} className="mt-1.5 h-12 w-full rounded-xl border border-input bg-background/40 px-4 text-sm outline-none placeholder:text-muted-foreground focus:border-primary" />
    </div>
  );
}
